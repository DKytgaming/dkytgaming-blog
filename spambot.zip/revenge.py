import pyautogui as spam
import time

limit = int(input("No. of message you want to send: "))
msg   = input("message you want to sent: ")

i = 0

time.sleep(5)

for i in range(limit):

    spam.typewrite(msg)
    spam.press('Enter')

i+=1